public interface ICDCodeTabular {
    public String getDescription(String diseaseCode) throws IndexOutOfBoundsException;
}
