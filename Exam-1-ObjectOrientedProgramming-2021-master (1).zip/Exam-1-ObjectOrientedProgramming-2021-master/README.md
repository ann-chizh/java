# Exam 1 Object-Oriented Programming 2021

---

*The proposed solution to exam #1 in the subject of Object-Oriented Programming, Maria Curie-Skłodowska University in Lublin*

---

This repository contains the proposed solution to Exam #1 in the subject of Object-Oriented Programming at Maria Curie-Skłodowska University in Lublin.

## Files

- `kol1_2021.pdf`: This file contains the exam tasks in PDF format. 
You can access it via this link: https://github.com/llutsefer/Exam-1-ObjectOrientedProgramming-2021/files/11378013/kol1_2021.pdf

## Disclaimer

Please note that this proposed solution is just one possible way to solve the problems presented in the examand and it is not guaranteed that my solution is correct. There may be other valid approaches that can be used to solve the same problems.
